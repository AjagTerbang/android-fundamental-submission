package com.example.androidfundamentalsubmission1.exception

class OutOfTimeException(message:String): Exception(message)