package com.example.androidfundamentalsubmission1.model

data class eventUpcomming (
    val id: Int,
    val imageUrl: String,
    val title: String,
)